class Game
{
    /**
     * Type:            <Optinal>
     * Description:     This method will be called once when the state will become active and can be used to init data.
     *                  if true is retured the state will beome active, otherwise the state will not be added to the stack.
     */
    init() 
    { 
        return true; 
    }

    /**
     * Type:            <Required>
     * Description:     This method will be called every frame and will update the state of the game.
     *                  If true is returened the state will remain active, otherwise the state will pop from the stack
     * Parameters:      elapsedTime - time in miliseconds that elapsed since the last time the method was called.
     */
    update(elapsedTime) 
    { 
        return true; 
    }

    /**
     * Type:            <Required>
     * Description:     This method will be called every frame after update was called to redraw the sate to the canvas.
     * Parameters:      ctx - context object that can draw to the canvas with the noemal canvas methods.
     */
    draw(ctx) 
    {

    }

    /**
     * Type:            <Optinal>
     * Description:     If this method is implemented, it will handle all the keyboard events while the state is active.
     *                  ( This method provides more info from the static dictionary 'SE.keys' )
     * Parameters:      e - The key event that was fired
     */
    
     //handleKeysEvent(e) {}

    /**
     * Type:            <Optinal>
     * Description:     If this method is implemented, it will handle all the mouse events while the state is active.
     * Parameters:      e - The mouse event that was fired
     */
    
    // handleMouseEvent(e) {}
}